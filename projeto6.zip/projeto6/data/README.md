baixa os csvs aqui: https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce

precisa de:
olist_orders_dataset.csv
olist_order_items_dataset.csv
olist_customers_dataset.csv
