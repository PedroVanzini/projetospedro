# Análise de Vendas - E-commerce Olist

Análise dos dados do Olist (marketplace brasileiro) pra responder umas perguntas simples de negócio: qual mês vendeu mais, quais estados compram mais e quanto tempo demora a entrega.

## Perguntas que o projeto responde
- Qual mês teve mais receita?
- Quais estados compram mais?
- Quanto tempo leva a entrega, em média, por estado?
- Quantos pedidos foram cancelados ou entregues?

## Tecnologias usadas
MySQL e Python (Pandas + Matplotlib)

## Estrutura
```
projeto6/
├── sql/            queries usadas na análise
├── scripts/        script python que faz a mesma análise
├── data/           onde colocar os csvs (não versionado)
└── outputs/        gráficos e csv gerados pelo script
```

## Como rodar
Baixa o dataset no Kaggle, coloca os 3 csvs (orders, order_items, customers) dentro da pasta `data/` e roda:

```
pip install -r requirements.txt
python scripts/analise.py
```

As queries de `sql/` também rodam direto num MySQL local, se quiser testar o mesmo resultado em SQL.

Dataset: https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce
