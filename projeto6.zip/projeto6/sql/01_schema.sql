CREATE DATABASE IF NOT EXISTS vendas_varejo;
USE vendas_varejo;

-- pedidos feitos na loja
CREATE TABLE pedidos (
    order_id        VARCHAR(40) PRIMARY KEY,
    customer_id     VARCHAR(40) NOT NULL,
    status_pedido   VARCHAR(20),
    data_compra     DATETIME,
    data_entrega    DATETIME
);

-- itens de cada pedido (um pedido pode ter varios itens)
CREATE TABLE itens_pedido (
    order_id    VARCHAR(40),
    item_id     INT,
    product_id  VARCHAR(40),
    seller_id   VARCHAR(40),
    preco       DECIMAL(10,2),
    frete       DECIMAL(10,2),
    PRIMARY KEY (order_id, item_id),
    FOREIGN KEY (order_id) REFERENCES pedidos(order_id)
);

CREATE TABLE clientes (
    customer_id  VARCHAR(40) PRIMARY KEY,
    cidade       VARCHAR(60),
    estado       CHAR(2)
);
