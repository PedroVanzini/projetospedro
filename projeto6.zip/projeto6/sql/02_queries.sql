-- receita e pedidos por mes
SELECT
    YEAR(p.data_compra)            AS ano,
    MONTH(p.data_compra)           AS mes,
    COUNT(DISTINCT p.order_id)     AS total_pedidos,
    ROUND(SUM(i.preco), 2)         AS receita_total,
    ROUND(AVG(i.preco), 2)         AS ticket_medio
FROM pedidos p
INNER JOIN itens_pedido i ON p.order_id = i.order_id
WHERE p.status_pedido = 'delivered'
GROUP BY YEAR(p.data_compra), MONTH(p.data_compra)
ORDER BY ano, mes;


-- top 10 estados que mais compram
SELECT
    c.estado,
    COUNT(DISTINCT p.order_id)  AS total_pedidos,
    ROUND(SUM(i.preco), 2)      AS receita_total
FROM pedidos p
INNER JOIN itens_pedido i ON p.order_id = i.order_id
INNER JOIN clientes c     ON p.customer_id = c.customer_id
WHERE p.status_pedido = 'delivered'
GROUP BY c.estado
ORDER BY receita_total DESC
LIMIT 10;


-- tempo medio de entrega por estado
SELECT
    c.estado,
    COUNT(DISTINCT p.order_id) AS pedidos_entregues,
    ROUND(AVG(DATEDIFF(p.data_entrega, p.data_compra)), 1) AS media_dias_entrega
FROM pedidos p
INNER JOIN clientes c ON p.customer_id = c.customer_id
WHERE p.status_pedido = 'delivered'
  AND p.data_entrega IS NOT NULL
GROUP BY c.estado
ORDER BY media_dias_entrega DESC;


-- quantidade de pedidos por status
SELECT
    status_pedido,
    COUNT(*) AS quantidade
FROM pedidos
GROUP BY status_pedido
ORDER BY quantidade DESC;
