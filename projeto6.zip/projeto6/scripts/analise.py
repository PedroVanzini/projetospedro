# analise de vendas - olist
# le os csvs, junta as tabelas e calcula receita por mes e por estado

import pandas as pd
import matplotlib.pyplot as plt

plt.rcParams["figure.figsize"] = (10, 5)

pedidos = pd.read_csv("data/olist_orders_dataset.csv")
itens = pd.read_csv("data/olist_order_items_dataset.csv")
clientes = pd.read_csv("data/olist_customers_dataset.csv")

pedidos["data_compra"] = pd.to_datetime(pedidos["order_purchase_timestamp"])
pedidos["ano"] = pedidos["data_compra"].dt.year
pedidos["mes"] = pedidos["data_compra"].dt.month

entregues = pedidos[pedidos["order_status"] == "delivered"].copy()

df = entregues.merge(itens, on="order_id", how="inner")
df = df.merge(clientes, on="customer_id", how="left")

# receita por mes
mensal = (
    df.groupby(["ano", "mes"])
    .agg(total_pedidos=("order_id", "nunique"), receita=("price", "sum"))
    .reset_index()
    .sort_values(["ano", "mes"])
)
print(mensal)

# top 10 estados
estados = (
    df.groupby("customer_state")
    .agg(pedidos=("order_id", "nunique"), receita=("price", "sum"))
    .reset_index()
    .sort_values("receita", ascending=False)
    .head(10)
)
print(estados)

# graficos
plt.bar(range(len(mensal)), mensal["receita"], color="#4a7fc1")
plt.title("Receita mensal")
plt.savefig("outputs/receita_mensal.png", dpi=150)
plt.close()

plt.barh(estados["customer_state"], estados["receita"], color="#5b9e6f")
plt.gca().invert_yaxis()
plt.title("Top 10 estados por receita")
plt.savefig("outputs/top_estados.png", dpi=150)
plt.close()

mensal.to_csv("outputs/receita_mensal.csv", index=False)
estados.to_csv("outputs/top_estados.csv", index=False)
