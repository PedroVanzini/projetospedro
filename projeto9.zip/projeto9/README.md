# Pipeline de Dados com Databricks + PySpark

Projeto que fiz pra praticar PySpark e entender como funciona uma arquitetura de dados em camadas (bronze, silver e gold), usando os dados do Olist.

## O que o pipeline faz
- bronze: lê os csvs brutos e salva em parquet, sem mudar nada
- silver: limpa, tipa as colunas certas e tira duplicados
- gold: junta as tabelas com Spark SQL e calcula receita por estado

## Tecnologias usadas
Databricks Community Edition, PySpark, Parquet

## Estrutura
```
projeto9/
├── notebooks/
│   └── pipeline_olist.py
└── data/
```

## Como rodar
Cria uma conta no Databricks Community Edition (é gratuito), sobe os csvs do Olist pra `/FileStore/tables/olist/raw/` e importa o notebook `pipeline_olist.py` direto no workspace.

Dataset: https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce
