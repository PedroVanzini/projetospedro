# Análise do ENEM por Estado

Análise dos microdados do ENEM olhando pra diferença de desempenho entre estados, entre escola pública e privada, e entre os sexos.

## Perguntas que o projeto responde
- Quais estados têm a maior média no ENEM?
- Qual a diferença de nota entre escola pública e privada?
- Como as notas de redação se distribuem?
- Tem diferença de desempenho entre os sexos?

## Tecnologias usadas
MySQL e Python (Pandas, Seaborn)

## Estrutura
```
projeto7/
├── sql/
├── scripts/
├── data/
└── outputs/
```

## Como rodar
Baixa os microdados do ENEM no site do INEP, salva uma amostra (uns 100 mil registros já é suficiente) em `data/microdados_enem.csv` e roda:

```
pip install -r requirements.txt
python scripts/analise.py
```

Fonte: https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/microdados/enem
