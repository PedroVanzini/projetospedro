# analise enem - diferenca de nota por estado e tipo de escola

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_style("whitegrid")

colunas = ["SG_UF_PROVA", "TP_SEXO", "TP_ESCOLA",
           "NU_NOTA_CN", "NU_NOTA_CH", "NU_NOTA_LC", "NU_NOTA_MT", "NU_NOTA_REDACAO"]

df = pd.read_csv("data/microdados_enem.csv", sep=";", encoding="latin-1",
                  usecols=colunas, nrows=100_000)

df.columns = ["estado", "sexo", "tipo_escola", "nota_cn", "nota_ch",
              "nota_lc", "nota_mt", "nota_redacao"]

df = df[df["nota_mt"].notna() & df["nota_redacao"].notna()].copy()
df["media_geral"] = df[["nota_cn", "nota_ch", "nota_lc", "nota_mt", "nota_redacao"]].mean(axis=1)
df["tipo_escola"] = df["tipo_escola"].map({1: "Publica", 2: "Privada"})

# media por estado
por_estado = (
    df.groupby("estado")["media_geral"]
    .mean()
    .round(1)
    .sort_values(ascending=False)
    .reset_index()
)
print(por_estado)

plt.figure(figsize=(12, 6))
plt.bar(por_estado["estado"], por_estado["media_geral"], color="#4a7fc1")
plt.title("Media geral do ENEM por estado")
plt.tight_layout()
plt.savefig("outputs/media_por_estado.png", dpi=150)
plt.close()

# publica vs privada
escola = df[df["tipo_escola"].notna()].groupby("tipo_escola")[["nota_mt", "nota_redacao"]].mean().round(1)
print(escola)

escola.plot(kind="bar", figsize=(7, 5))
plt.title("Publica vs privada")
plt.tight_layout()
plt.savefig("outputs/publica_privada.png", dpi=150)
plt.close()

por_estado.to_csv("outputs/media_por_estado.csv", index=False)
