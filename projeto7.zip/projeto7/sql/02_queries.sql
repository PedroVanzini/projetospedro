-- media geral por estado
SELECT
    sg_uf_prova AS estado,
    COUNT(*) AS candidatos,
    ROUND(AVG(nu_nota_mt), 1)      AS media_matematica,
    ROUND(AVG(nu_nota_redacao), 1) AS media_redacao,
    ROUND((AVG(nu_nota_mt) + AVG(nu_nota_lc) + AVG(nu_nota_cn)
           + AVG(nu_nota_ch) + AVG(nu_nota_redacao)) / 5, 1) AS media_geral
FROM candidatos
WHERE nu_nota_mt IS NOT NULL AND nu_nota_redacao IS NOT NULL
GROUP BY sg_uf_prova
ORDER BY media_geral DESC;


-- escola publica x privada
SELECT
    CASE tp_escola WHEN 1 THEN 'Publica' WHEN 2 THEN 'Privada' ELSE 'Nao informado' END AS tipo_escola,
    COUNT(*) AS candidatos,
    ROUND(AVG(nu_nota_mt), 1)      AS media_matematica,
    ROUND(AVG(nu_nota_redacao), 1) AS media_redacao
FROM candidatos
WHERE nu_nota_mt IS NOT NULL AND tp_escola IN (1, 2)
GROUP BY tp_escola;


-- faixas de nota de redacao
SELECT
    CASE
        WHEN nu_nota_redacao < 400 THEN '0-399'
        WHEN nu_nota_redacao < 600 THEN '400-599'
        WHEN nu_nota_redacao < 800 THEN '600-799'
        WHEN nu_nota_redacao < 900 THEN '800-899'
        ELSE '900-1000'
    END AS faixa_nota,
    COUNT(*) AS quantidade
FROM candidatos
WHERE nu_nota_redacao IS NOT NULL
GROUP BY faixa_nota
ORDER BY faixa_nota;


-- nota media por sexo
SELECT
    CASE tp_sexo WHEN 'M' THEN 'Masculino' ELSE 'Feminino' END AS sexo,
    ROUND(AVG(nu_nota_mt), 1)      AS media_matematica,
    ROUND(AVG(nu_nota_redacao), 1) AS media_redacao,
    COUNT(*) AS candidatos
FROM candidatos
WHERE nu_nota_mt IS NOT NULL
GROUP BY tp_sexo;
