CREATE DATABASE IF NOT EXISTS analise_enem;
USE analise_enem;

CREATE TABLE candidatos (
    nu_inscricao      BIGINT PRIMARY KEY,
    sg_uf_prova       CHAR(2),
    tp_sexo           CHAR(1),
    tp_escola         INT,            -- 1 publica, 2 privada
    nu_nota_cn        DECIMAL(6,1),
    nu_nota_ch        DECIMAL(6,1),
    nu_nota_lc        DECIMAL(6,1),
    nu_nota_mt        DECIMAL(6,1),
    nu_nota_redacao   DECIMAL(6,1)
);

LOAD DATA LOCAL INFILE 'data/enem_amostra.csv'
INTO TABLE candidatos
CHARACTER SET utf8mb4
FIELDS TERMINATED BY ';'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;
