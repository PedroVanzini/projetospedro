baixa os microdados aqui: https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/microdados/enem

salva como: microdados_enem.csv (uma amostra ja serve, nao precisa do arquivo completo)
