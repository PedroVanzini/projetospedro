# analise de acidentes aereos no brasil - dados do cenipa

import pandas as pd
import matplotlib.pyplot as plt

ocorrencia = pd.read_csv("data/ocorrencia.csv", sep=";", encoding="utf-8")
fator = pd.read_csv("data/fator_contribuinte.csv", sep=";", encoding="utf-8")

ocorrencia["data_ocorrencia"] = pd.to_datetime(ocorrencia["ocorrencia_dia"], format="%d/%m/%Y", errors="coerce")
ocorrencia["mes"] = ocorrencia["data_ocorrencia"].dt.month

acidentes = ocorrencia[ocorrencia["ocorrencia_classificacao"] == "ACIDENTE"].copy()

# acidentes por estado
por_estado = (
    acidentes.groupby("uf_ocorrencia")
    .agg(total=("codigo_ocorrencia", "count"), fatais=("total_fatais", "sum"))
    .reset_index()
    .sort_values("total", ascending=False)
)
print(por_estado.head(10))

plt.barh(por_estado["uf_ocorrencia"].head(10), por_estado["total"].head(10), color="#4a7fc1")
plt.gca().invert_yaxis()
plt.title("Top 10 estados por numero de acidentes")
plt.tight_layout()
plt.savefig("outputs/acidentes_por_estado.png", dpi=150)
plt.close()

# acidentes por mes
por_mes = acidentes.groupby("mes").size().reset_index(name="total")
print(por_mes)

plt.bar(por_mes["mes"], por_mes["total"], color="#c96a3a")
plt.title("Acidentes por mes")
plt.tight_layout()
plt.savefig("outputs/acidentes_por_mes.png", dpi=150)
plt.close()

# fatores humanos mais comuns
fator_humano = fator[fator["fator_area"] == "FATOR HUMANO"]
top_fatores = fator_humano["fator_nome"].value_counts().head(10).reset_index()
top_fatores.columns = ["fator_nome", "ocorrencias"]
print(top_fatores)

plt.barh(top_fatores["fator_nome"], top_fatores["ocorrencias"], color="#5b7fa6")
plt.gca().invert_yaxis()
plt.title("Top 10 fatores humanos")
plt.tight_layout()
plt.savefig("outputs/top_fatores_humanos.png", dpi=150)
plt.close()

por_estado.to_csv("outputs/acidentes_por_estado.csv", index=False)
