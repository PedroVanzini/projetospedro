# Análise de Acidentes Aéreos no Brasil

Análise dos dados do CENIPA tentando achar padrão nos acidentes aéreos: quais estados têm mais ocorrências, se tem sazonalidade por mês e quais os fatores humanos mais comuns.

## Perguntas que o projeto responde
- Quais estados concentram mais acidentes?
- Tem algum mês com mais ocorrência que outro?
- Quais os fatores humanos que mais aparecem?
- Como isso evoluiu ano a ano?

## Tecnologias usadas
MySQL (com uma window function de exemplo) e Python (Pandas, Matplotlib)

## Estrutura
```
projeto8/
├── sql/
├── scripts/
├── data/
└── outputs/
```

## Como rodar
Baixa `ocorrencia.csv` e `fator_contribuinte.csv` no dados.gov.br, coloca em `data/` e roda:

```
pip install -r requirements.txt
python scripts/analise.py
```

Fonte: https://dados.gov.br/dados/conjuntos-dados/ocorrencias-aeronauticas-da-aviacao-civil-brasileira
