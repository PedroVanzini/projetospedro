-- ranking de estados por numero de acidentes
SELECT
    uf_ocorrencia,
    COUNT(*)          AS total_acidentes,
    SUM(total_fatais) AS total_fatais,
    RANK() OVER (ORDER BY COUNT(*) DESC) AS ranking
FROM ocorrencia
WHERE classificacao = 'ACIDENTE' AND uf_ocorrencia IS NOT NULL
GROUP BY uf_ocorrencia
ORDER BY total_acidentes DESC;


-- acidentes por mes (sazonalidade)
SELECT
    MONTH(data_ocorrencia) AS mes,
    COUNT(*)               AS total_acidentes,
    SUM(total_fatais)      AS total_fatais
FROM ocorrencia
WHERE classificacao = 'ACIDENTE'
GROUP BY MONTH(data_ocorrencia)
ORDER BY mes;


-- top 10 fatores humanos
SELECT
    f.fator,
    COUNT(*) AS ocorrencias
FROM ocorrencia o
INNER JOIN fator_contribuinte f ON o.codigo_ocorrencia = f.codigo_ocorrencia
WHERE f.area = 'HUMANO'
GROUP BY f.fator
ORDER BY ocorrencias DESC
LIMIT 10;


-- evolucao anual
SELECT
    YEAR(data_ocorrencia) AS ano,
    COUNT(*)               AS total_acidentes,
    SUM(total_fatais)      AS total_fatais
FROM ocorrencia
WHERE classificacao = 'ACIDENTE'
GROUP BY YEAR(data_ocorrencia)
ORDER BY ano;
