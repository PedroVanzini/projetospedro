CREATE DATABASE IF NOT EXISTS acidentes_aereos;
USE acidentes_aereos;

CREATE TABLE ocorrencia (
    codigo_ocorrencia   INT PRIMARY KEY,
    data_ocorrencia     DATE NOT NULL,
    uf_ocorrencia       CHAR(2),
    fase_operacao       VARCHAR(40),
    classificacao       VARCHAR(30),
    total_fatais        INT DEFAULT 0
);

CREATE TABLE aeronave (
    id_aeronave         INT AUTO_INCREMENT PRIMARY KEY,
    codigo_ocorrencia   INT NOT NULL,
    tipo_veiculo        VARCHAR(30),
    fabricante          VARCHAR(50),
    FOREIGN KEY (codigo_ocorrencia) REFERENCES ocorrencia(codigo_ocorrencia)
);

CREATE TABLE fator_contribuinte (
    id_fator            INT AUTO_INCREMENT PRIMARY KEY,
    codigo_ocorrencia   INT NOT NULL,
    fator               VARCHAR(100),
    area                VARCHAR(40),
    FOREIGN KEY (codigo_ocorrencia) REFERENCES ocorrencia(codigo_ocorrencia)
);
