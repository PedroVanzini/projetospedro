baixa os dados aqui: https://dados.gov.br/dados/conjuntos-dados/ocorrencias-aeronauticas-da-aviacao-civil-brasileira

precisa de:
ocorrencia.csv
fator_contribuinte.csv
